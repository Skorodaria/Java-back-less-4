import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach
import static io.restassured.RestAssured.given;

public class LoadTest extends AbstractTest {

    @BeforeAll
    static void setUp() {

        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();

    }

    @Test
    void getRequestLogTest() {
        given()
                .queryParam("apiKey", getApiKey())
                .queryParam("includeNutrition", "false")
                .queryParam("Number", "033698816271")
                .log().method()
                .log().params()
                .when()
                .get("https://api.spoonacular.com/recipes/complexSearch");

        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++=");

        given()
                .queryParam("apiKey", getApiKey())
                .queryParam("includeNutrition", "false")
                .log().all()
                .when()
                .get("https://api.spoonacular.com/recipes/complexSearch");
    }

    @Test
    void getResponseLogTest() {
        given()
                .queryParam("apiKey", getApiKey())
                .queryParam("includeNutrition", "false")
                .log().all()
                .when()
                .get("https://api.spoonacular.com/recipes/complexSearch")
                .prettyPeek();
    }

    @Test
    void getErrorTest() {
        given()
                .queryParam("apiKey", getApiKey())
                .queryParam("includeNutrition", "false")
                .when()
                .get("https://api.spoonacular.com/recipes/complexSearch")
                .then().statusCode(201);
    }

    @AfterEach
    void tearDown() {
        given()
                .queryParam("hash", "a3da66460bfb7e62ea1c96cfa0b7a634a346ccbf")
                .queryParam("apiKey", "3e6cc9c807c84d0ba3518045b86e6687")
                .delete("https://api.spoonacular.com/mealplanner/geekbrains/items/" + id)
                .then()
                .statusCode(200);
    }

}