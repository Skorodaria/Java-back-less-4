import org.junit.Test;

public class RecipeTests extends AbstractTest {

   @Test
   public void getRecipeWithQueryParametersPositiveTest() {
       given()
               .queryParam("apiKey", getApiKey())
               .queryParam("includeNutrition", "false")
               .log().method()
               .log().params()
               .when()
               .get("https://api.spoonacular.com/recipes/complexSearch");
   }

    @Test
    public void getRecipePositiveTest() {
        given()
                .when()
                .get("https://spoonacular.com/food-api/updates" +
                        "includeNutrition=false&apiKey=d1321207e33d46e3b5e36f8a9b892aa8")
                .then()
                .statusCode(200);
    }

    public io.restassured.RestAssured given() {
        return null;
    }

    @Test
    public void getRecipeNegativeTest() {

        given()

                .when()
                .get("https://api.spoonacular.com/recipes/complexSearch")
                .then()
                .statusCode(401);
    }

    @Test
    public void getRecipePositiveTestSpaghettiAglioetOlio() {
        given()
                .when()
                .get("https://api.spoonacular.com/recipes/guessNutrition?title=Spaghetti Aglio et Olio" +
                        "includeNutrition=false&apiKey=d1321207e33d46e3b5e36f8a9b892aa8")
                .then()
                .statusCode(200);
    }

 @Test
    public void getRecipePositiveTestNutritionbyId() {
         given()
             .when()
             .get("https://api.spoonacular.com/recipes/{id}/nutritionWidget.json" +
                     "includeNutrition=false&apiKey=d1321207e33d46e3b5e36f8a9b892aa8")
                .then()
                .statusCode(200);

             
 }
  @Test
    public void getComparableProductsPositiveTest() {
      given()
              .queryParam("apiKey", "d1321207e33d46e3b5e36f8a9b892aa8")
              .gueryParam("Number", "033698816271")
              .when()
              .get("https://spoonacular.com/food-api/docs#Get-Comparable-Products")
              .then
              .statusCode(200);
  }
}
  @Test
    public void postRecipeInstructionsPositiveTest() {
      given()
              .getClass("apiKey")
              .contentType("application/x-www-form-urlencoded")
              .formParam("instructions= Put the gurlic in a pan and then add the onion. Add some salt and oregano.")
              .when()
              .post(AbstractTest.getBaseUrl())
              .then()
              .statusCode(200);
  }
  @Test
    public void postRecipeParseIngredientsPositiveTest() {
       given()
               .getClass("apiKey", "d1321207e33d46e3b5e36f8a9b892aa8")
               .contentType("application/x-www-form-urlencoded")
               .formParam("1 cup green tea")
               .when()
               .post(AbstractTest.getBaseUrl())
               .then()
               .statusCode(200);
  }
  @Test
    public void postComputeGlycemycloadPositiveTest() {
       given()
               .getClass("apiKey", "d1321207e33d46e3b5e36f8a9b892aa8")
               .body("
                       "ingredients":[
      "1 kiwi",
              "2 cups rice",
              "2 glasses of water"
    ]")
                .when()
                .post(AbstractTest.getBaseUrl())
                .then()
                .statusCode(200);
  }
 @Test
    public void postClassifyGroceryProductBulk() {
       given()
               .getClass("apiKey", "d1321207e33d46e3b5e36f8a9b892aa8")
               .body(
               [{ "title": "Kroger Vitamin A & D Reduced Fat 2% Milk", "upc": "", "plu_code": "" }])
               .when
               .post(AbstractTest.getBaseUrl())
              .then()
              .statusCode(200);


 }
      @Test
   public void postMapIngredientstoGroceryProducts() {
    .getClass("apiKey", "d1321207e33d46e3b5e36f8a9b892aa8")
                  .body(
                  [ { "ingredients": ["eggs","bacon"], "servings": 2 } ])
                  .when
                  .post(AbstractTest.getBaseUrl())
                  .then()
                  .statusCode(200);

}

    @Test
    void addMealTest() {
        id = given()
                .queryParam("hash", "a3da66460bfb7e62ea1c96cfa0b7a634a346ccbf")
                .queryParam("apiKey", "d1321207e33d46e3b5e36f8a9b892aa8")
                .body("{\n"
                        + " \"date\": 1644881179,\n"
                        + " \"slot\": 1,\n"
                        + " \"position\": 0,\n"
                        + " \"type\": \"INGREDIENTS\",\n"
                        + " \"value\": {\n"
                        + " \"ingredients\": [\n"
                        + " {\n"
                        + " \"name\": \"1 banana\"\n"
                        + " }\n"
                        + " ]\n"
                        + " }\n"
                        + "}")
                .when()
                .post("https://api.spoonacular.com/mealplanner/geekbrains/items")
                .then()
                .statusCode(200)
                .extract()
                .jsonPath()
                .get("id")
                .toString();
    }
    @AfterEach
    void tearDown() {
        given()
                .queryParam("hash", "a3da66460bfb7e62ea1c96cfa0b7a634a346ccbf")
                .queryParam("apiKey", "3e6cc9c807c84d0ba3518045b86e6687")
                .delete("https://api.spoonacular.com/mealplanner/geekbrains/items/" + id)
                .then()
                .statusCode(200);



